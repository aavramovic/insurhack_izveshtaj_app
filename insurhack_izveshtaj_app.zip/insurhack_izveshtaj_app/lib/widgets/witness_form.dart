import 'package:flutter/material.dart';
import 'package:insurhack_izveshtaj_app/providers/witness.dart';

class WitnessForm extends StatefulWidget {
  @override
  _WitnessFormState createState() => _WitnessFormState();
}

class _WitnessFormState extends State<WitnessForm> {
  final _form = GlobalKey<FormState>();
  var _witness = Witness(name: '', telephoneNumber: '', address: '');

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16.0),
      child: Form(
        key: _form,
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(8.0),
              child: TextFormField(
                onSaved: (value) {

                },
                decoration: InputDecoration(
                  labelText: 'Име и презиме',
                  icon: Icon(Icons.person),
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  TextFormField(
                    initialValue: widget.witness.telephoneNumber,
                    onSaved: (value) => widget.witness.telephoneNumber = value,
                    decoration: InputDecoration(
                      labelText: 'Телефонски број',
                      icon: Icon(Icons.phone_android),
                    ),
                  ),
                  TextFormField(
                    initialValue: widget.witness.address,
                    onSaved: (value) => widget.witness.address = value,
                    decoration: InputDecoration(
                      labelText: 'Адреса на живеење',
                      icon: Icon(Icons.person_pin_circle),
                    ),
                  )
                ],
              )
            )
          ],
        )
      )
    );
  }

  bool validate() {
    var valid = form.currentState.validate();
    if (valid) form.currentState.save();
    return valid;
  }
}
