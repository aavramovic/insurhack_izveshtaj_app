class Driver {
String surname;
String name;
String birthdate;
String address;
String country;
String telephoneNumber;
String email;
String licenceNumber;
String licenceCategory;
String licenceValidUntil;

  Driver({
    this.surname,
    this.name,
    this.birthdate,
    this.address,
    this.country,
    this.telephoneNumber,
    this.email,
    this.licenceNumber,
    this.licenceCategory,
    this.licenceValidUntil
  });

}
